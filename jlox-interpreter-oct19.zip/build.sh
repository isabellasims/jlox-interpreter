set -e

javac -classpath . *.java
java -classpath . Main