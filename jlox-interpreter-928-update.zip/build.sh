javac -classpath . *.java
java -classpath . Main